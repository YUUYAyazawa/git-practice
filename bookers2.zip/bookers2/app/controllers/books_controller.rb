class BooksController < ApplicationController
 def new
    @book = Book.new 
 end

  def index
      @user = current_user 
      @books = Book.all
      @book = Book.new
    end


  def show
    @book = Book.find(params[:id])
    @user = @book.user
  end

  def edit
    @book = Book.find(params[:id])
    if @book.user != current_user
      redirect_to books_path
    end
  end

  def create
    @books=Book.all
    @book = Book.new(book_params)
    @book.user_id =current_user.id
    @user = current_user
    if @book.save
      flash[:notice] = "You have created book successfully."
      redirect_to book_path(@book.id)
    else
      
      render :index 
    end
  end

  def update
    @books=Book.all
    @book = Book.find(params[:id])
    if @book.update(book_params)
      flash[:notice] = "You have created book successfully."
      redirect_to book_path(@book.id)
    else
      flash.now[:notice] = "2 errors prohibited this obj from being saved::"
      render :edit # ★要修正
   end
  end

  def destroy
    book = Book.find(params[:id])
    book.destroy
    redirect_to books_path
  end

  private
# ストロングパラメーター
def book_params
  params.require(:book).permit(:title, :body)
end
end

